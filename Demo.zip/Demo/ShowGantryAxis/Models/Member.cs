﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShowGantryAxis.Models
{
    public class Member
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Role { get; set; }

        public string Info => $"{Name}, {Age}岁, {Role}";
    }

    public class Team
    {
        public string TeamName { get; set; }
        public ObservableCollection<Member> Members { get; set; } = new ObservableCollection<Member>();
    }
}
