﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ShowGantryAxis.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ShowGantryAxis.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        public ObservableCollection<Team> Teams { get; set; }

        public MainViewModel()
        {
            Teams = new ObservableCollection<Team>();
            InitializeTeams();
        }

        private void InitializeTeams()
        {
            var teamA = new Team { TeamName = "团队A" };
            teamA.Members.Add(new Member { Name = "张三", Age = 25, Role = "开发者" });
            teamA.Members.Add(new Member { Name = "李四", Age = 28, Role = "测试" });

            var teamB = new Team { TeamName = "团队B" };
            teamB.Members.Add(new Member { Name = "王五", Age = 30, Role = "项目经理" });
            teamB.Members.Add(new Member { Name = "赵六", Age = 27, Role = "设计师" });

            var teamC = new Team { TeamName = "团队C" };
            teamB.Members.Add(new Member { Name = "胡七", Age = 30, Role = "项目经理" });
            teamB.Members.Add(new Member { Name = "苏八", Age = 27, Role = "设计师" });

            Teams.Add(teamA);
            Teams.Add(teamB);
        }

        [RelayCommand]
        public void ShowDetails(Member member)
        {
            if (member != null)
            {
                MessageBox.Show($"成员信息：{member.Info}", "成员详情", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
